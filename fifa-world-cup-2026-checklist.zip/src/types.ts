export interface StickerDefinition {
  stickerNumber: string;
  playerName: string;
  teamCountry: string;
  sectionCode: string;
  group?: string;
}

export interface CollectionItem {
  sticker: StickerDefinition;
  quantity: number;
}

export type Collection = Record<string, number>; // stickerNumber -> quantity

export interface TradeMatchInfo {
  theirRepeatsIWant: StickerDefinition[];
  theirRepeatsIAlreadyHave: StickerDefinition[];
  theirMissingICanGive: StickerDefinition[];
  theirMissingIDontHave: StickerDefinition[];
}
