import { StoreProvider, useStore } from './store';
import { useState } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './components/ui/Tabs';
import { Checklist } from './components/Checklist';
import { Repeats } from './components/Repeats';
import { Missing } from './components/Missing';
import { Trade } from './components/Trade';
import { Settings } from './components/Settings';
import { TopBar } from './components/TopBar';

function AppContent() {
  const { isLoading, t } = useStore();
  const [activeTab, setActiveTab] = useState('checklist');

  if (isLoading) {
    return <div className="flex items-center justify-center min-h-screen bg-slate-950 text-slate-100"><p className="text-xl font-bold uppercase tracking-widest text-emerald-500 animate-pulse">Loading Collection...</p></div>;
  }

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 font-sans p-4 sm:p-6 overflow-hidden flex flex-col">
      <div className="max-w-7xl mx-auto w-full flex-1 flex flex-col gap-4">
        <TopBar />
        
        <Tabs value={activeTab} onValueChange={setActiveTab} className="flex-1 flex flex-col gap-4 min-h-0">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-4 flex flex-col sm:flex-row items-center justify-between gap-4">
            <h2 className="text-xs font-black uppercase tracking-[0.2em] text-emerald-500 hidden sm:block">Database</h2>
            <TabsList className="bg-slate-950 rounded-xl p-1 border border-slate-700 w-full sm:w-auto overflow-x-auto justify-start">
              <TabsTrigger value="checklist">{t('Checklist')}</TabsTrigger>
              <TabsTrigger value="repeats">{t('Repeats')}</TabsTrigger>
              <TabsTrigger value="missing">{t('Missing')}</TabsTrigger>
              <TabsTrigger value="trade">{t('Trade')}</TabsTrigger>
              <TabsTrigger value="settings">{t('Settings')}</TabsTrigger>
            </TabsList>
          </div>
          
          <div className="flex-1 bg-slate-900/30 border border-slate-800 rounded-3xl overflow-hidden flex flex-col relative min-h-[60vh]">
            <div className="absolute inset-0 overflow-y-auto custom-scrollbar bg-slate-900/50">
              <TabsContent value="checklist" className="mt-0 outline-none h-full">
                <Checklist />
              </TabsContent>
              <TabsContent value="repeats" className="mt-0 outline-none h-full">
                <Repeats />
              </TabsContent>
              <TabsContent value="missing" className="mt-0 outline-none h-full">
                <Missing />
              </TabsContent>
              <TabsContent value="trade" className="mt-0 outline-none h-full p-4 sm:p-6">
                <Trade />
              </TabsContent>
              <TabsContent value="settings" className="mt-0 outline-none h-full p-4 sm:p-6">
                <Settings />
              </TabsContent>
            </div>
          </div>
        </Tabs>
      </div>
    </div>
  );
}

export default function App() {
  return (
    <StoreProvider>
      <AppContent />
    </StoreProvider>
  );
}
