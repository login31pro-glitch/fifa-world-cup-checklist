import { useStore } from '../store';
import { StickerCard } from './StickerCard';
import { useMemo, useState, useEffect } from 'react';
import { Search, Filter } from 'lucide-react';

export function Checklist() {
  const { stickers, collection, t } = useStore();
  const [search, setSearch] = useState('');
  const [groupFilter, setGroupFilter] = useState('');
  const [teamSectionFilter, setTeamSectionFilter] = useState('');

  const availableGroups = useMemo(() => {
    const list = teamSectionFilter 
      ? stickers.filter(s => `${s.teamCountry}${s.sectionCode ? ` / ${s.sectionCode}` : ''}` === teamSectionFilter)
      : stickers;
    return Array.from(new Set(list.map(s => s.group).filter(Boolean)));
  }, [stickers, teamSectionFilter]);

  const availableTeamSections = useMemo(() => {
    const list = groupFilter 
      ? stickers.filter(s => s.group === groupFilter)
      : stickers;
    return Array.from(new Set(list.map(s => `${s.teamCountry}${s.sectionCode ? ` / ${s.sectionCode}` : ''}`)));
  }, [stickers, groupFilter]);

  useEffect(() => {
    if (groupFilter && !availableGroups.includes(groupFilter)) {
      setGroupFilter('');
    }
  }, [availableGroups, groupFilter]);

  useEffect(() => {
    if (teamSectionFilter && !availableTeamSections.includes(teamSectionFilter)) {
      setTeamSectionFilter('');
    }
  }, [availableTeamSections, teamSectionFilter]);

  const filteredStickers = useMemo(() => {
    return stickers.filter(s => {
      const matchGroup = groupFilter === '' || s.group === groupFilter;
      const ts = `${s.teamCountry}${s.sectionCode ? ` / ${s.sectionCode}` : ''}`;
      const matchTeamSection = teamSectionFilter === '' || ts === teamSectionFilter;
      const matchSearch = search === '' || 
        s.playerName.toLowerCase().includes(search.toLowerCase()) || 
        s.stickerNumber.toLowerCase().includes(search.toLowerCase());
      
      return matchGroup && matchTeamSection && matchSearch;
    });
  }, [stickers, search, groupFilter, teamSectionFilter]);

  // Group by section inside filtered
  const grouped = useMemo(() => {
    const gps: Record<string, StickerDefinition[]> = {};
    filteredStickers.forEach(s => {
      const groupKey = `${t(s.teamCountry)} ${s.sectionCode ? `(${s.sectionCode})` : ''}`.trim();
      if (!gps[groupKey]) gps[groupKey] = [];
      gps[groupKey].push(s);
    });
    return gps;
  }, [filteredStickers, t]);

  return (
    <div className="pb-8">
      {/* Filter Bar */}
      <div className="sticky top-0 z-20 bg-slate-900/95 backdrop-blur-md border-b border-slate-800 p-4 sm:p-6 flex flex-col md:flex-row gap-4 mb-6 shadow-xl shadow-slate-950/20">
        <div className="flex-1 relative">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
          <input 
            type="text" 
            placeholder={t('Search by name or number...')} 
            value={search}
            onChange={e => setSearch(e.target.value)}
            className="w-full bg-slate-950 border border-slate-700 rounded-xl pl-10 pr-4 py-2 text-sm text-slate-100 focus:outline-none focus:border-emerald-500 transition-colors"
          />
        </div>
        
        <div className="flex flex-wrap gap-2">
          <select 
            value={groupFilter} 
            onChange={(e) => setGroupFilter(e.target.value)}
            className="bg-slate-950 border border-slate-700 rounded-xl px-4 py-2 text-sm text-slate-300 focus:outline-none focus:border-emerald-500"
          >
            <option value="">{t('All Groups')}</option>
            {availableGroups.length > 0 ? (
              availableGroups.map((g: any) => <option key={g} value={g}>{t(g)}</option>)
            ) : (
              // Fallback options if CSV does not have groups
              Array.from({ length: 12 }, (_, i) => String.fromCharCode(65 + i)).map(letter => (
                <option key={letter} value={letter}>{t(`Group ${letter}`)}</option>
              ))
            )}
          </select>
          
          <select 
            value={teamSectionFilter} 
            onChange={(e) => setTeamSectionFilter(e.target.value)}
            className="bg-slate-950 border border-slate-700 rounded-xl px-4 py-2 text-sm text-slate-300 focus:outline-none focus:border-emerald-500"
          >
            <option value="">{t('All Teams / Sections')}</option>
            {availableTeamSections.map((ts) => {
              const [country, code] = ts.split(' / ');
              const translatedTs = code ? `${t(country)} / ${code}` : t(country);
              return <option key={ts} value={ts}>{translatedTs}</option>;
            })}
          </select>
        </div>
      </div>

      {Object.keys(grouped).length === 0 ? (
        <div className="text-center py-24 text-slate-500">
          <Filter className="w-12 h-12 mx-auto mb-4 opacity-50" />
          <p className="text-lg font-bold uppercase tracking-widest text-slate-600">No matching stickers</p>
        </div>
      ) : (
        <div className="space-y-10 px-4 sm:px-6">
          {Object.entries(grouped).map(([team, groupStickers]: [string, any]) => (
            <div key={team} className="space-y-4">
              <h2 className="text-xs font-black uppercase tracking-[0.2em] text-slate-400 flex items-center gap-3">
                <span>{team}</span>
                <span className="text-[10px] bg-slate-800 text-slate-400 px-2 py-0.5 rounded-md">
                  {groupStickers.length}
                </span>
                <div className="flex-1 h-px bg-slate-800"></div>
              </h2>
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-3 sm:gap-4">
                {groupStickers.map(s => (
                  <StickerCard key={s.stickerNumber} sticker={s} />
                ))}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
