import { useStore } from '../store';
import { StickerCard } from './StickerCard';
import { useMemo, useState } from 'react';
import { Search } from 'lucide-react';

export function Missing() {
  const { stickers, collection, t } = useStore();
  const [search, setSearch] = useState('');

  const missingList = useMemo(() => {
    return stickers.filter(s => {
      const q = collection[s.stickerNumber] || 0;
      if (q > 0) return false;
      if (search && !s.playerName.toLowerCase().includes(search.toLowerCase()) && !s.stickerNumber.toLowerCase().includes(search.toLowerCase())) return false;
      return true;
    });
  }, [stickers, collection, search]);

  return (
    <div className="pb-8">
      <div className="sticky top-0 z-20 bg-slate-900/95 backdrop-blur-md border-b border-slate-800 p-4 sm:p-6 mb-6 shadow-xl shadow-slate-950/20 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h2 className="text-xs font-black uppercase tracking-[0.2em] text-rose-500 mb-1">{t('Missing Cards')}</h2>
          <p className="text-sm text-slate-400">{missingList.length} {t('cards remaining')}</p>
        </div>
        
        <div className="relative w-full md:max-w-xs">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
          <input 
            type="text" 
            placeholder={t('Search missing cards...')} 
            value={search}
            onChange={e => setSearch(e.target.value)}
            className="w-full bg-slate-950 border border-slate-700 rounded-xl pl-10 pr-4 py-2 text-sm text-slate-100 focus:outline-none focus:border-emerald-500 transition-colors"
          />
        </div>
      </div>

      <div className="px-4 sm:px-6">
        {missingList.length === 0 ? (
          <div className="text-center py-24 text-slate-500 bg-slate-900 border border-slate-800 rounded-3xl">
          <p className="text-lg font-bold uppercase tracking-widest text-slate-600">{t('Collection Complete!')}</p>
        </div>
      ) : (
          <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-4 gap-3 sm:gap-4">
            {missingList.map(s => (
              <StickerCard key={s.stickerNumber} sticker={s} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
