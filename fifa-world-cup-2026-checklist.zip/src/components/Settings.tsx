import { useState, ChangeEvent } from 'react';
import { useStore } from '../store';
import { Upload, Download, Trash2, AlertTriangle, X } from 'lucide-react';

import { LANGUAGES, Language } from '../lib/i18n';

export function Settings() {
  const { collection, username, importData, clearCollection, language, setLanguage, t } = useStore();
  const [showClearConfirm, setShowClearConfirm] = useState(false);

  const handleExport = () => {
    const exportData = {
      version: 2,
      username,
      collection
    };
    const jsonStr = JSON.stringify(exportData, null, 2);
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `world-cup-collection-${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const handleImport = (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const parsed = JSON.parse(event.target?.result as string);
        if (typeof parsed === 'object' && parsed !== null) {
          if (parsed.version === 2 && parsed.collection) {
            // New format
            const valid = Object.entries(parsed.collection).every(([k, v]) => typeof k === 'string' && typeof v === 'number' && v >= 0);
            if (valid) {
              importData(parsed.collection as Record<string, number>, parsed.username as string);
              alert('Collection imported successfully!');
            } else {
              alert('Invalid collection file format. Quantities must be non-negative numbers.');
            }
          } else {
            // Legacy format
            const valid = Object.entries(parsed).every(([k, v]) => typeof k === 'string' && typeof v === 'number' && v >= 0);
            if (valid) {
              importData(parsed as Record<string, number>);
              alert('Collection imported successfully!');
            } else {
              alert('Invalid collection file format. Quantities must be non-negative numbers.');
            }
          }
        }
      } catch (err) {
        alert('Failed to parse JSON file.');
      }
    };
    reader.readAsText(file);
    e.target.value = ''; // reset
  };

  const confirmClear = () => {
    clearCollection();
    setShowClearConfirm(false);
  };

  return (
    <div className="max-w-2xl space-y-8 relative">
      <div>
        <h2 className="text-xs font-black uppercase tracking-[0.2em] text-slate-400 mb-2">{t('Settings')}</h2>
        <p className="text-sm text-slate-500">{t('Manage your collection data')}</p>
      </div>

      <div className="space-y-4">
        {/* Language Selector */}
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 flex flex-col sm:flex-row items-start sm:items-center gap-4 justify-between">
          <div>
            <h3 className="font-bold text-slate-200">{t('Language')}</h3>
          </div>
          <select 
            value={language} 
            onChange={(e) => setLanguage(e.target.value as Language)}
            className="bg-slate-950 border border-slate-700 rounded-xl px-4 py-2 text-sm text-slate-300 focus:outline-none focus:border-emerald-500 w-full sm:w-auto"
          >
            {LANGUAGES.map(lang => (
              <option key={lang.value} value={lang.value}>{lang.label}</option>
            ))}
          </select>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 flex flex-col sm:flex-row items-start sm:items-center gap-4 justify-between">
          <div>
            <h3 className="font-bold text-slate-200">{t('Export Data')}</h3>
            <p className="text-sm text-slate-500">Save a backup of your collected stickers as a JSON file.</p>
          </div>
          <button 
            onClick={handleExport}
            className="flex items-center justify-center w-full sm:w-auto gap-2 p-2 bg-slate-800 rounded-xl hover:bg-slate-700 border border-slate-700 text-xs font-bold text-white transition-colors uppercase tracking-widest shrink-0"
          >
            <Download className="w-4 h-4" /> {t('Download Backup')}
          </button>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 flex flex-col sm:flex-row items-start sm:items-center gap-4 justify-between">
          <div>
            <h3 className="font-bold text-slate-200">{t('Import Data')}</h3>
            <p className="text-sm text-slate-500">Restore your collection from a previous JSON backup.</p>
          </div>
          <label className="flex items-center justify-center w-full sm:w-auto gap-2 p-2 bg-emerald-600 rounded-xl hover:bg-emerald-500 text-slate-950 text-xs font-bold transition-colors uppercase tracking-widest shrink-0 cursor-pointer">
            <Upload className="w-4 h-4" /> {t('Upload Backup')}
            <input type="file" accept=".json" className="hidden" onChange={handleImport} />
          </label>
        </div>
      </div>

      <div className="pt-8 border-t border-slate-800">
        <div className="bg-rose-950/20 border border-rose-900/50 rounded-3xl p-5 flex flex-col sm:flex-row items-start sm:items-center gap-4 justify-between relative overflow-hidden">
          <div className="relative z-10">
            <h3 className="font-bold text-rose-500 flex items-center gap-2">
              <AlertTriangle className="w-4 h-4" /> {t('Danger Zone')}
            </h3>
            <p className="text-sm text-rose-400/80 mt-1">Erase your entire collection and start from scratch.</p>
          </div>
          <button 
            onClick={() => setShowClearConfirm(true)}
            className="relative z-10 flex items-center justify-center w-full sm:w-auto gap-2 p-2 bg-rose-600 rounded-xl hover:bg-rose-500 border border-rose-500 text-xs font-bold text-white transition-colors uppercase tracking-widest shrink-0"
          >
            <Trash2 className="w-4 h-4" /> {t('Clear Collection')}
          </button>
          
          <div className="absolute top-0 right-0 p-8 opacity-5 pointer-events-none text-rose-500">
            <AlertTriangle className="w-32 h-32" />
          </div>
        </div>
      </div>

      {showClearConfirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 max-w-sm w-full shadow-2xl relative animate-in fade-in zoom-in duration-200">
            <button 
              onClick={() => setShowClearConfirm(false)}
              className="absolute top-4 right-4 text-slate-500 hover:text-slate-300 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
            <div className="mb-6 flex flex-col items-center text-center">
              <div className="w-16 h-16 bg-rose-500/10 rounded-full flex items-center justify-center text-rose-500 mb-4 border border-rose-500/20">
                <Trash2 className="w-8 h-8" />
              </div>
              <h3 className="text-xl font-bold text-slate-200 mb-2">{t('Clear Collection')}</h3>
              <p className="text-slate-400 text-sm">
                {t('Are you sure you want to clear your entire collection?')}
              </p>
            </div>
            <div className="flex flex-col gap-3">
              <button 
                onClick={confirmClear}
                className="w-full flex items-center justify-center gap-2 p-3 bg-rose-600 rounded-xl hover:bg-rose-500 text-sm font-bold text-white transition-colors tracking-wide"
              >
                {t('Yes, clear everything')}
              </button>
              <button 
                onClick={() => setShowClearConfirm(false)}
                className="w-full flex items-center justify-center gap-2 p-3 bg-slate-800 rounded-xl hover:bg-slate-700 border border-slate-700 text-sm font-bold text-white transition-colors tracking-wide"
              >
                {t('Cancel')}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
