import { Trophy, Edit2 } from 'lucide-react';
import { useStore } from '../store';
import { useState, useRef, useEffect } from 'react';

export function TopBar() {
  const { collection, stickers, username, setUsername, t } = useStore();
  const [isEditingUsername, setIsEditingUsername] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);
  
  const regularStickers = stickers.filter(s => s.group !== 'Extra Stickers');
  const totalOwned = regularStickers.filter(s => (collection[s.stickerNumber] || 0) > 0).length;
  const percentage = regularStickers.length > 0 ? ((totalOwned / regularStickers.length) * 100).toFixed(1) : "0.0";

  useEffect(() => {
    if (isEditingUsername && inputRef.current) {
      inputRef.current.focus();
    }
  }, [isEditingUsername]);

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      setIsEditingUsername(false);
    }
  };

  return (
    <header className="flex flex-col sm:flex-row items-start sm:items-center justify-between mb-2 bg-slate-900/50 p-4 rounded-3xl border border-slate-800 gap-4 sm:gap-0">
      <div className="flex items-center gap-4">
        <div className="w-12 h-12 bg-emerald-500 rounded-xl flex items-center justify-center shadow-lg shadow-emerald-500/20 shrink-0">
          <Trophy className="w-8 h-8 text-slate-950" />
        </div>
        <div>
          <h1 className="text-xl font-bold tracking-tight text-white uppercase line-clamp-1">{t('World Cup 2026 Checklist')}</h1>
          <div className="hidden sm:flex items-center gap-2 group mt-0.5">
            <span className="text-xs text-slate-400 font-mono uppercase tracking-widest">{t('Collector')}:</span>
            {isEditingUsername ? (
              <input
                ref={inputRef}
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                onBlur={() => setIsEditingUsername(false)}
                onKeyDown={handleKeyDown}
                maxLength={20}
                className="bg-slate-800 text-xs text-slate-200 font-mono uppercase tracking-widest px-2 py-0.5 rounded outline-none border border-slate-600 w-32"
                placeholder={t('USERNAME')}
              />
            ) : (
              <button 
                onClick={() => setIsEditingUsername(true)}
                className="text-xs text-slate-300 font-mono uppercase tracking-widest flex items-center gap-1.5 hover:text-white transition-colors"
              >
                {username}
                <Edit2 className="w-3 h-3 opacity-0 group-hover:opacity-100 transition-opacity" />
              </button>
            )}
          </div>
        </div>
      </div>
      
      <div className="flex gap-4 sm:gap-8 items-center w-full sm:w-auto">
        <div className="text-right flex-1 sm:flex-none">
          <p className="text-[10px] text-slate-500 uppercase font-bold tracking-widest">{t('Total Collection')}</p>
          <p className="text-2xl font-black text-emerald-400">{percentage}%</p>
        </div>
        <div className="w-32 sm:w-48 h-2 bg-slate-800 rounded-full overflow-hidden shrink-0">
          <div 
            className="h-full bg-emerald-500 shadow-[0_0_10px_rgba(16,185,129,0.5)] transition-all duration-500" 
            style={{ width: `${percentage}%` }}
          />
        </div>
      </div>
    </header>
  );
}
