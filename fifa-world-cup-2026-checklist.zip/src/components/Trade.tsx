import { useStore } from '../store';
import { useState, useMemo } from 'react';
import { Copy, Plus, ClipboardPaste, Send, Check } from 'lucide-react';
import { StickerCard } from './StickerCard';

export function Trade() {
  const { stickers, collection, t } = useStore();
  const [tradeCodeInput, setTradeCodeInput] = useState('');
  const [copied, setCopied] = useState(false);
  const [copiedMsg, setCopiedMsg] = useState(false);
  const [matchResult, setMatchResult] = useState<{
    theirRepeatsIWant: string[];
    theirRepeatsIHave: string[];
    theirMissingICanGive: string[];
    theirMissingICannotGive: string[];
  } | null>(null);

  const [selectedToGive, setSelectedToGive] = useState<Set<string>>(new Set());
  const [selectedToWant, setSelectedToWant] = useState<Set<string>>(new Set());

  const myRepeats = useMemo(() => stickers.filter(s => (collection[s.stickerNumber] || 0) >= 2).map(s => s.stickerNumber), [stickers, collection]);
  const myMissing = useMemo(() => stickers.filter(s => (collection[s.stickerNumber] || 0) === 0).map(s => s.stickerNumber), [stickers, collection]);

  const myTradeCode = useMemo(() => {
    return ['repeats', ...myRepeats, 'missing', ...myMissing].join(',');
  }, [myRepeats, myMissing]);

  const handleCopyCode = async () => {
    try {
      await navigator.clipboard.writeText(myTradeCode);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (e) {
      console.error('Failed to copy');
    }
  };

  const handleProcessCode = () => {
    if (!tradeCodeInput.trim()) return;

    try {
      const parts = tradeCodeInput.split(',').map(s => s.trim()).filter(Boolean);
      const repeatsIdx = parts.indexOf('repeats');
      const missingIdx = parts.indexOf('missing');

      if (repeatsIdx === -1 || missingIdx === -1) {
        alert('Invalid trade code format. Must contain "repeats" and "missing" markers.');
        return;
      }

      let theirRepeatsRaw: string[] = [];
      let theirMissingRaw: string[] = [];

      if (repeatsIdx < missingIdx) {
        theirRepeatsRaw = parts.slice(repeatsIdx + 1, missingIdx);
        theirMissingRaw = parts.slice(missingIdx + 1);
      } else {
        theirMissingRaw = parts.slice(missingIdx + 1, repeatsIdx);
        theirRepeatsRaw = parts.slice(repeatsIdx + 1);
      }

      const knownIds = new Set(stickers.map(s => s.stickerNumber));

      const theirRepeats = Array.from(new Set(theirRepeatsRaw)).filter(id => knownIds.has(id));
      const theirMissing = Array.from(new Set(theirMissingRaw)).filter(id => knownIds.has(id));

      const theirRepeatsIWant = theirRepeats.filter(id => (collection[id] || 0) === 0);
      const theirRepeatsIHave = theirRepeats.filter(id => (collection[id] || 0) > 0);

      const theirMissingICanGive = theirMissing.filter(id => (collection[id] || 0) >= 2);
      const theirMissingICannotGive = theirMissing.filter(id => (collection[id] || 0) < 2);

      setMatchResult({
        theirRepeatsIWant,
        theirRepeatsIHave,
        theirMissingICanGive,
        theirMissingICannotGive
      });
      setSelectedToGive(new Set()); // Reset selections
      setSelectedToWant(new Set());
    } catch (e) {
      alert('Failed to parse trade code.');
    }
  };

  const toggleSelectToGive = (id: string) => {
    setSelectedToGive(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const toggleSelectToWant = (id: string) => {
    setSelectedToWant(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const generateMessage = () => {
    if (!matchResult) return '';
    const canGiveArr = Array.from(selectedToGive);
    const wantArr = Array.from(selectedToWant);

    let msg = 'Trade Proposal\n\n';
    if (canGiveArr.length > 0) {
      msg += 'I can trade:\n' + canGiveArr.join('\n') + '\n\n';
    } else {
      msg += 'I can trade:\n(None selected)\n\n';
    }

    if (wantArr.length > 0) {
      msg += 'I am interested in:\n' + wantArr.join('\n');
    } else {
      msg += 'I am interested in:\n(None selected)';
    }

    return msg;
  };

  const handleCopyMsg = async () => {
    try {
      await navigator.clipboard.writeText(generateMessage());
      setCopiedMsg(true);
      setTimeout(() => setCopiedMsg(false), 2000);
    } catch (e) {
      console.error('Failed to copy');
    }
  };

  return (
    <div className="flex flex-col lg:flex-row gap-6 max-w-full">
      {/* Sidebar: Codes */}
      <div className="w-full lg:w-80 bg-slate-900 border border-slate-800 rounded-3xl p-5 flex flex-col gap-6 lg:sticky lg:top-0 h-max shrink-0">
        <h2 className="text-xs font-black uppercase tracking-[0.2em] text-emerald-500">{t('Trade')}</h2>
        
        <div className="flex-1 flex flex-col gap-6">
          <div className="space-y-3">
              <label className="text-[10px] text-slate-500 uppercase font-bold tracking-widest">{t('Your Trade Code')}</label>
              <div className="bg-slate-950 border border-slate-800 p-3 rounded-xl text-xs font-mono break-all text-slate-400 h-32 overflow-y-auto custom-scrollbar">
                  {myTradeCode}
              </div>
              <button 
                onClick={handleCopyCode}
                className="w-full py-2 bg-slate-800 rounded-xl text-xs font-bold border border-slate-700 hover:bg-slate-700 uppercase tracking-widest text-slate-100 flex items-center justify-center gap-2"
              >
                {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                {copied ? t('Copied!') : t('Copy Code')}
              </button>
          </div>

          <div className="space-y-3 pt-6 border-t border-slate-800">
              <label className="text-[10px] text-slate-500 uppercase font-bold tracking-widest">{t('Received a Code?')}</label>
              <textarea 
                placeholder={t('Enter trade code...')} 
                value={tradeCodeInput}
                onChange={e => setTradeCodeInput(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 p-3 rounded-xl text-xs font-mono h-32 focus:border-blue-500 focus:outline-none resize-none custom-scrollbar text-slate-300"
              />
              <button 
                onClick={handleProcessCode}
                className="w-full py-2 bg-blue-600 rounded-xl text-xs font-bold hover:bg-blue-500 uppercase tracking-widest text-white"
              >
                {t('Check Match')}
              </button>
          </div>
        </div>

        <div className="bg-slate-950/50 p-4 rounded-2xl border border-slate-800 hidden lg:block">
          <p className="text-xs text-slate-400 leading-relaxed">
              <span className="text-emerald-400 font-bold block mb-1">Pro Tip:</span> 
              {t('Trade feature helps you')}
          </p>
        </div>
      </div>

      {/* Main Area: Match Results */}
      <div className="flex-1 space-y-8 min-w-0">
        {!matchResult ? (
          <div className="h-full min-h-[40vh] border border-slate-800 border-dashed rounded-3xl flex items-center justify-center text-slate-500 p-8 text-center bg-slate-900/30">
            <div>
              <ClipboardPaste className="w-12 h-12 mx-auto mb-4 opacity-30" />
              <p className="font-medium">Paste a partner's code to analyze matching cards.</p>
            </div>
          </div>
        ) : (
          <div className="space-y-8 animate-in fade-in duration-500">
            {/* Cards I Want */}
            <div className="bg-slate-900 border border-emerald-500/20 rounded-3xl p-5 sm:p-6 shadow-lg shadow-emerald-500/5">
              <h3 className="text-sm font-black uppercase tracking-[0.2em] text-emerald-400 mb-4 flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-emerald-500"></span> 
                {t('Stickers you need that they have duplicates of')}
              </h3>
              
              {matchResult.theirRepeatsIWant.length > 0 ? (
                <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-4 gap-3">
                  {matchResult.theirRepeatsIWant.map(id => {
                    const s = stickers.find(st => st.stickerNumber === id)!;
                    const isSelected = selectedToWant.has(id);
                    return (
                      <div 
                        key={id} 
                        onClick={() => toggleSelectToWant(id)}
                        className={`cursor-pointer transition-all border-2 rounded-2xl overflow-hidden ${isSelected ? 'border-emerald-500 ring-2 ring-emerald-500/20 shadow-[0_0_15px_rgba(16,185,129,0.3)]' : 'border-transparent opacity-80 hover:opacity-100'}`}
                      >
                        <StickerCard sticker={s} readOnly={true} />
                        {isSelected && (
                          <div className="bg-emerald-600 text-white text-[10px] font-bold uppercase tracking-widest text-center py-1">
                            {t('SELECTED TO RECEIVE') || 'SELECTED TO RECEIVE'}
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              ) : (
                <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 text-sm text-slate-500">
                  {t('Nothing to receive')}
                </div>
              )}

              {matchResult.theirRepeatsIHave.length > 0 && (
                <div className="mt-6 pt-4 border-t border-slate-800">
                  <h4 className="text-[10px] uppercase font-bold text-slate-500 mb-3 tracking-widest">Not Matching (I already own these)</h4>
                  <div className="flex flex-wrap gap-2">
                    {matchResult.theirRepeatsIHave.map(id => (
                      <span key={id} className="text-xs px-2 py-1 bg-slate-950 text-slate-500 rounded-md font-mono border border-slate-800">
                        {id}
                      </span>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Cards I Can Offer */}
            <div className="bg-slate-900 border border-blue-500/20 rounded-3xl p-5 sm:p-6 shadow-lg shadow-blue-500/5">
              <h3 className="text-sm font-black uppercase tracking-[0.2em] text-blue-400 mb-4 flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-blue-500"></span>
                {t('Stickers they need that you have duplicates of')}
              </h3>
              
              {matchResult.theirMissingICanGive.length > 0 ? (
                <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-4 gap-3">
                  {matchResult.theirMissingICanGive.map(id => {
                    const s = stickers.find(st => st.stickerNumber === id)!;
                    const isSelected = selectedToGive.has(id);
                    return (
                      <div 
                        key={id} 
                        onClick={() => toggleSelectToGive(id)}
                        className={`cursor-pointer transition-all border-2 rounded-2xl overflow-hidden ${isSelected ? 'border-blue-500 ring-2 ring-blue-500/20 shadow-[0_0_15px_rgba(59,130,246,0.3)]' : 'border-transparent opacity-80 hover:opacity-100'}`}
                      >
                        <StickerCard sticker={s} readOnly={true} />
                        {isSelected && (
                          <div className="bg-blue-600 text-white text-[10px] font-bold uppercase tracking-widest text-center py-1">
                            {t('SELECTED TO TRADE') || 'SELECTED TO TRADE'}
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              ) : (
                <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 text-sm text-slate-500">
                  {t('Nothing to give')}
                </div>
              )}

              {matchResult.theirMissingICannotGive.length > 0 && (
                <div className="mt-6 pt-4 border-t border-slate-800">
                  <h4 className="text-[10px] uppercase font-bold text-slate-500 mb-3 tracking-widest">Not Matching (I don't have extra copies)</h4>
                  <div className="flex flex-wrap gap-2">
                    {matchResult.theirMissingICannotGive.map(id => (
                      <span key={id} className="text-xs px-2 py-1 bg-slate-950 text-slate-500 rounded-md font-mono border border-slate-800">
                        {id}
                      </span>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Trade Builder Message */}
            <div className="bg-slate-950 rounded-3xl p-6 sm:p-8 border border-slate-800">
              <h3 className="text-sm font-black uppercase tracking-[0.2em] text-slate-200 mb-4 flex items-center gap-2">
                <Send className="w-4 h-4 text-slate-400" />
                {t('Trade Proposal Generation') || 'Trade Proposal Generation'}
              </h3>
              
              <div className="bg-slate-900 rounded-2xl p-4 sm:p-6 border border-slate-800 mb-4">
                <pre className="whitespace-pre-wrap font-mono text-xs leading-relaxed text-slate-300">
                  {generateMessage()}
                </pre>
              </div>

              <div className="flex justify-end">
                <button 
                  onClick={handleCopyMsg}
                  className="w-full sm:w-auto py-3 px-6 bg-slate-800 rounded-xl text-xs font-bold border border-slate-700 hover:bg-slate-700 uppercase tracking-widest text-slate-100 flex items-center justify-center gap-2 transition-colors"
                >
                  {copiedMsg ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                  {copiedMsg ? t('Copied!') : t('Copy Code')}
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
