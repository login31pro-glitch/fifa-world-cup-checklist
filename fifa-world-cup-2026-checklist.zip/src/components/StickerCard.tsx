import { StickerDefinition } from '../types';
import { useStore } from '../store';
import { cn } from '../lib/utils';
import { memo } from 'react';

function StickerCardComponent({ sticker, readOnly = false }: { sticker: StickerDefinition, readOnly?: boolean }) {
  const { collection, updateQuantity, t } = useStore();
  const quantity = collection[sticker.stickerNumber] || 0;
  
  const hasSticker = quantity > 0;
  const isRepeat = quantity > 1;

  return (
    <div className={cn(
      "rounded-2xl p-3 flex flex-col gap-3 group transition-colors",
      hasSticker 
        ? "bg-slate-900 border shadow-lg" 
        : "bg-slate-900 border border-slate-700 hover:border-emerald-500/50 opacity-50 hover:opacity-100",
      hasSticker && !isRepeat && "border-emerald-500/30 ring-1 ring-emerald-500/20 shadow-emerald-500/5",
      isRepeat && "border-amber-500/30 ring-1 ring-amber-500/20 shadow-amber-500/5"
    )}>
      <div className="flex justify-between items-start gap-2">
        <span className={cn(
          "text-sm font-mono px-2.5 py-1 rounded-md uppercase font-black tracking-wide shrink-0",
           hasSticker 
            ? (isRepeat ? "bg-amber-500 text-slate-950" : "bg-emerald-500 text-slate-950") 
            : "bg-slate-800 text-slate-300"
        )}>
          {sticker.stickerNumber}
        </span>
        <span className={cn(
          "text-[10px] font-bold uppercase tracking-widest text-right truncate group-hover:whitespace-normal group-hover:overflow-visible group-hover:break-words",
          hasSticker 
            ? (isRepeat ? "text-amber-500" : "text-emerald-500") 
            : "text-slate-500"
        )}>
          {t(sticker.teamCountry)}
        </span>
      </div>
      
      <h3 className="text-sm font-bold truncate group-hover:whitespace-normal group-hover:overflow-visible group-hover:break-words" title={sticker.playerName}>
        {sticker.playerName}
      </h3>

      {readOnly ? (
        <div className={cn(
          "flex items-center justify-center mt-auto rounded-xl p-2",
          hasSticker 
            ? (isRepeat ? "bg-amber-500/10" : "bg-emerald-500/10") 
            : "bg-slate-950"
        )}>
           <span className={cn(
            "text-sm font-black",
            hasSticker ? (isRepeat ? "text-amber-400" : "text-emerald-400") : "text-slate-400"
          )}>
            {quantity}
          </span>
        </div>
      ) : (
        <div className={cn(
          "flex items-center justify-between mt-auto rounded-xl p-2",
          hasSticker 
            ? (isRepeat ? "bg-amber-500/10" : "bg-emerald-500/10") 
            : "bg-slate-950"
        )}>
          <button 
            onClick={() => updateQuantity(sticker.stickerNumber, -1)}
            disabled={quantity === 0}
            className="w-8 h-8 flex items-center justify-center bg-slate-800 rounded-lg text-rose-400 hover:bg-slate-700 font-bold disabled:opacity-30 disabled:pointer-events-none transition-colors"
          >
            -
          </button>
          
          <input 
            type="number"
            min="0"
            value={quantity}
            onChange={(e) => updateQuantity(sticker.stickerNumber, e.target.value)}
            className={cn(
              "text-sm font-black w-12 text-center bg-transparent border-none focus:outline-none hide-arrows",
              hasSticker ? (isRepeat ? "text-amber-400" : "text-emerald-400") : "text-white"
            )}
          />
          
          <button 
            onClick={() => updateQuantity(sticker.stickerNumber, 1)}
            className={cn(
              "w-8 h-8 flex items-center justify-center rounded-lg font-bold transition-colors",
              hasSticker 
                ? (isRepeat ? "bg-amber-500 text-slate-950 hover:bg-amber-400" : "bg-emerald-500 text-slate-950 hover:bg-emerald-400") 
                : "bg-slate-800 text-white hover:bg-slate-700 hover:text-emerald-400"
            )}
          >
            +
          </button>
        </div>
      )}
    </div>
  );
}

export const StickerCard = memo(StickerCardComponent);
