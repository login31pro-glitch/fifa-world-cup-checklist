import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import Papa from 'papaparse';
import { StickerDefinition, Collection } from './types';
import { Language, useTranslation as buildTranslator } from './lib/i18n';

// @ts-ignore
import rawCsv from './data.csv?raw';

interface StoreState {
  stickers: StickerDefinition[];
  collection: Collection;
  isLoading: boolean;
  username: string;
  setUsername: (name: string) => void;
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
  updateQuantity: (id: string, delta: number | string) => void;
  importData: (data: Collection, username?: string) => void;
  clearCollection: () => void;
  theme: 'light' | 'dark';
  toggleTheme: () => void;
}

const StoreContext = createContext<StoreState | undefined>(undefined);

export function StoreProvider({ children }: { children: ReactNode }) {
  const [stickers, setStickers] = useState<StickerDefinition[]>([]);
  const [collection, setCollection] = useState<Collection>({});
  const [username, setUsername] = useState('Collector');
  const [language, setLanguage] = useState<Language>('system');
  const [isLoading, setIsLoading] = useState(true);
  const [theme, setTheme] = useState<'light' | 'dark'>('light');

  const t = buildTranslator(language);

  useEffect(() => {
    // Load theme
    const savedTheme = localStorage.getItem('theme');
    if (savedTheme === 'dark' || savedTheme === 'light') {
      setTheme(savedTheme);
      if (savedTheme === 'dark') {
        document.documentElement.classList.add('dark');
      }
    } else if (window.matchMedia('(prefers-color-scheme: dark)').matches) {
      setTheme('dark');
      document.documentElement.classList.add('dark');
    }

    // Load CSV
    Papa.parse(rawCsv, {
      header: true,
      skipEmptyLines: true,
      complete: (results) => {
        const parsed = results.data.map((row: any) => ({
          stickerNumber: row['Sticker Number'] || row['stickerNumber'] || '',
          playerName: row['Player Name'] || row['playerName'] || '',
          teamCountry: row['Team Country'] || row['teamCountry'] || '',
          sectionCode: row['Section Code'] || row['sectionCode'] || '',
          group: row['Group Set'] || row['Group'] || row['group'] || '',
        })).filter((s: any) => s.stickerNumber);
        
        setStickers(parsed);

        // Load collection and username
        const savedCollection = localStorage.getItem('collection');
        if (savedCollection) {
          try {
            setCollection(JSON.parse(savedCollection));
          } catch (e) {
            console.error('Failed to parse saved collection');
          }
        }
        
        const savedUsername = localStorage.getItem('username');
        if (savedUsername) {
          setUsername(savedUsername);
        }

        const savedLanguage = localStorage.getItem('language');
        if (savedLanguage) {
          setLanguage(savedLanguage as Language);
        }
        
        setIsLoading(false);
      }
    });
  }, []);

  useEffect(() => {
    if (!isLoading) {
      localStorage.setItem('collection', JSON.stringify(collection));
      localStorage.setItem('username', username);
      localStorage.setItem('language', language);
    }
  }, [collection, username, language, isLoading]);

  useEffect(() => {
    localStorage.setItem('theme', theme);
    if (theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [theme]);

  const toggleTheme = () => {
    setTheme(t => t === 'light' ? 'dark' : 'light');
  };

  const updateQuantity = (id: string, delta: number | string) => {
    setCollection(prev => {
      let current = prev[id] || 0;
      let next = typeof delta === 'string' ? parseInt(delta, 10) : current + delta;
      if (isNaN(next) || next < 0) next = 0;
      return { ...prev, [id]: next };
    });
  };

  const importData = (data: Collection, importedUsername?: string) => {
    setCollection(data);
    if (importedUsername) {
      setUsername(importedUsername);
    }
  };

  const clearCollection = () => {
    setCollection({});
  };

  return (
    <StoreContext.Provider value={{ stickers, collection, isLoading, username, setUsername, language, setLanguage, t, updateQuantity, importData, clearCollection, theme, toggleTheme }}>
      {children}
    </StoreContext.Provider>
  );
}

export function useStore() {
  const context = useContext(StoreContext);
  if (context === undefined) {
    throw new Error('useStore must be used within a StoreProvider');
  }
  return context;
}
